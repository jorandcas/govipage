import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import { createClient } from '@supabase/supabase-js';

const app = express();

// --- ENV y clientes ---
const PORT = process.env.PORT || 5174;
const HOST = "0.0.0.0"; 
const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_ROLE = process.env.SERVICE_ROLE;

// Bucket de Storage: si no lo pones en .env, usa "portabilidad"
const BUCKET = process.env.SUPABASE_BUCKET || 'portabilidad';

if (!SUPABASE_URL) throw new Error('Missing SUPABASE_URL');
if (!SERVICE_ROLE) throw new Error('Missing SERVICE_ROLE');

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

// --- Middlewares ---
app.use(cors({ origin: true, credentials: true }));

// Para multipart/form-data
const upload = multer();

// Healthcheck
app.get('/health', (_req, res) => res.status(200).send('OK'));

// Utilidad simple para limpiar nombres
const sanitize = (s = '') => s.replace(/[^\w.\-]+/g, '_');

// Helper para subir al Storage usando SIEMPRE el BUCKET correcto
async function uploadToStorage({ buffer, mimetype, destPath }) {
  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(destPath, buffer, { contentType: mimetype, upsert: true });

  if (error) throw error;

  // Generamos una URL firmada 24h (útil para correos)
  const { data, error: urlErr } = await supabase.storage
    .from(BUCKET)
    .createSignedUrl(destPath, 60 * 60 * 24);

  if (urlErr) throw urlErr;

  return data?.signedUrl;
}

// --- Ruta principal ---
app.post(
  '/api/portabilidad',
  upload.fields([
    { name: 'ineFrente', maxCount: 1 },
    { name: 'ineReverso', maxCount: 1 },
    { name: 'frente', maxCount: 1 },
    { name: 'reverso', maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      // 1) Parse JSON embebido en multipart
      const rawData = req.body?.data || '{}';
      const data = JSON.parse(rawData);
      console.log('BODY data length:', rawData.length);

      // 2) Archivos
      const fFrente = req.files?.ineFrente?.[0] || req.files?.frente?.[0] || null;
      const fReverso = req.files?.ineReverso?.[0] || req.files?.reverso?.[0] || null;
      console.log('FILES:', { frente: fFrente?.originalname, reverso: fReverso?.originalname });
      if (!fFrente || !fReverso) {
        return res.status(400).json({ ok: false, error: 'INE frente y reverso son requeridos' });
      }

      // 3) Carpeta destino
      const now = new Date().toISOString().replace(/[:.]/g, '-');
      const carpeta = `portas/${now}-${sanitize(data?.numeroPortar || 'sin-numero')}`;

      // 4) Subir a Storage y obtener URLs firmadas
      const frentePath  = `${carpeta}/ine-frente-${sanitize(fFrente.originalname)}`;
      const reversoPath = `${carpeta}/ine-reverso-${sanitize(fReverso.originalname)}`;
      const urlFrente  = await uploadToStorage({ buffer: fFrente.buffer, mimetype: fFrente.mimetype, destPath: frentePath });
      const urlReverso = await uploadToStorage({ buffer: fReverso.buffer, mimetype: fReverso.mimetype, destPath: reversoPath });

      // 5) Insert en BD -> OBTÉN EL FOLIO AQUÍ
      const { data: inserted, error: dbError } = await supabase
        .from('portabilidades')
        .insert([{
          nombre_completo: data.nombreCompleto,
          email: data.email,
          numero_portar: data.numeroPortar,
          nip: data.nip,
          numero_contacto: data.numeroContacto,
          plan_elegido: data.planElegido || '',
          calle: data.calle,
          numero_exterior: data.numeroExterior,
          codigo_postal: data.codigoPostal,
          descripcion_vivienda: data.descripcionVivienda || '',
          storage_carpeta: carpeta,
          ine_frente_url: urlFrente,
          ine_reverso_url: urlReverso,
          created_at: new Date().toISOString(),
        }])
        .select('id')
        .single();

      if (dbError) {
        console.error('DB insert error:', dbError);
        return res.status(500).json({ ok: false, error: 'Error guardando en base de datos', detail: dbError.message });
      }

      // 6) Correos (DENTRO DEL MISMO SCOPE, usando inserted.id)
      const emailStatus = { mesa: null, cliente: null };

      // 6a) Mesa de control + CC
      try {
        const rMesa = await sendBrevoEmail({
          to: [process.env.MESA_CONTROL],
          cc: [process.env.CC_OPERACIONES],
          subject: `Nueva solicitud de portabilidad – Folio ${inserted.id}`,
          html: `
      <h2>Nueva solicitud</h2>
      <p><b>Folio:</b> ${inserted.id}</p>
      <p><b>Nombre:</b> ${data.nombreCompleto}</p>
      <p><b>Email:</b> ${data.email}</p>
      <p><b>Número a portar:</b> ${data.numeroPortar}</p>
      <p><b>NIP:</b> ${data.nip}</p>
      <p><b>Plan elegido:</b> ${data.planElegido || ''}</p>
      <p><b>Número de contacto:</b> ${data.numeroContacto}</p>
      <p><b>INE Frente:</b> <a href="${urlFrente}" target="_blank">Descargar</a></p>
      <p><b>INE Reverso:</b> <a href="${urlReverso}" target="_blank">Descargar</a></p>
      <h2>Datos de envio</h2>
      <p><b>Nombre Calle:</b> ${data.calle}</p>
      <p><b>Número Exterior:</b> ${data.numeroExterior}</p>
      <p><b>Codigo Postal:</b> ${data.codigoPostal}</p>
      <p><b>Descripción Casa:</b> ${data.descripcionVivienda || ''}</p>
    `,
        });
        emailStatus.mesa = { ok: true, resp: rMesa };
        console.log('[BREVO] Enviado a Mesa de Control');
      } catch (e) {
        emailStatus.mesa = { ok: false, error: e.message };
        console.error('[BREVO] Falló envío a Mesa de Control:', e.message);
      }

      // 6b) Confirmación al cliente
      try {
        const clienteEmail = String(data.email || '').trim();
        const nombre = String(data.nombreCompleto || '').trim().split(' ')[0] || '';
        if (!clienteEmail) {
          emailStatus.cliente = { ok: false, error: 'Email vacío' };
          console.warn('[BREVO] Email de cliente vacío; no se envía confirmación');
        } else {
          const rCliente = await sendBrevoEmail({
            to: [clienteEmail],
            subject: 'Hemos recibido tu solicitud de portabilidad',
            html: `
              <p>Hola ${nombre},</p>
              <p>Tu proceso de portabilidad ha iniciado con el <b>Folio ${inserted.id}</b>.</p>
              <p>Nos comunicaremos contigo a la brevedad para continuar con la entrega de tu SIM y la activación.</p>
              <br/>
              <p>— Distribuidor Movistar</p>
            `,
          });
          emailStatus.cliente = { ok: true, resp: rCliente };
          console.log('[BREVO] Enviado al cliente');
        }
      } catch (e) {
        emailStatus.cliente = { ok: false, error: e.message };
        console.error('[BREVO] Falló envío al cliente:', e.message);
      }

      // 7) Responder (AHORA sí al final)
      return res.json({
        ok: true,
        folio: inserted.id,
        carpeta,
        files: { frente: frentePath, reverso: reversoPath },
        urls: { frente: urlFrente, reverso: urlReverso },
        emailStatus,
      });

    } catch (err) {
      console.error('[POST /api/portabilidad] ERROR:', err);
      return res.status(500).json({ ok: false, error: err?.message || 'Server error' });
    }
  }
);




// ---------- Brevo helper ----------
async function sendBrevoEmail({ to, subject, html, cc = [], replyTo }) {
  if (!process.env.BREVO_API_KEY) {
    console.warn('[BREVO] BREVO_API_KEY no definido; omitiendo envío.');
    return { skipped: true };
  }

  const toList = (to || []).filter(Boolean).map(email => ({ email }));
  if (toList.length === 0) throw new Error('Parámetro "to" vacío');

  const ccList = (cc || []).filter(Boolean).map(email => ({ email }));

  const payload = {
    sender: { email: process.env.FROM_EMAIL, name: process.env.FROM_NAME },
    to: toList,
    subject,
    htmlContent: html,
  };
  if (ccList.length > 0) payload.cc = ccList;   // <-- sólo si hay CC
  if (replyTo) payload.replyTo = { email: replyTo };

  const resp = await fetch('https://api.brevo.com/v3/smtp/email', {
    method: 'POST',
    headers: {
      'api-key': process.env.BREVO_API_KEY,
      'content-type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const json = await resp.json().catch(() => ({}));
  if (!resp.ok) {
    console.error('[BREVO] Error', resp.status, json);
    throw new Error(json?.message || `Brevo ${resp.status}`);
  }
  return json;
}


// 5.a) Mesa de control (con CC)
try {
  await sendBrevoEmail({
    to: [process.env.MESA_CONTROL],
    cc: [process.env.CC_OPERACIONES],
    subject: `Nueva solicitud de portabilidad – Folio ${inserted.id}`,
    html: `
      <h2>Nueva solicitud</h2>
      <p><b>Folio:</b> ${inserted.id}</p>
      <p><b>Nombre:</b> ${data.nombreCompleto}</p>
      <p><b>Email:</b> ${data.email}</p>
      <p><b>Número a portar:</b> ${data.numeroPortar}</p>
      <p><b>NIP:</b> ${data.nip}</p>
      <p><b>Plan elegido:</b> ${data.planElegido || ''}</p>
      <p><b>Número de contacto:</b> ${data.numeroContacto}</p>
      <p><b>INE Frente:</b> <a href="${urlFrente}" target="_blank">Descargar</a></p>
      <p><b>INE Reverso:</b> <a href="${urlReverso}" target="_blank">Descargar</a></p>
      <h2>Datos de envio</h2>
      <p><b>Nombre Calle:</b> ${data.calle}</p>
      <p><b>Número Exterior:</b> ${data.numeroExterior}</p>
      <p><b>Codigo Postal:</b> ${data.codigoPostal}</p>
      <p><b>Descripción Casa:</b> ${data.descripcionVivienda || ''}</p>
    `,
  });
  console.log('[BREVO] Enviado a Mesa de Control');
} catch (e) {
  console.error('[BREVO] Falló envío a Mesa de Control:', e.message);
  // Si quieres que el flujo continue aunque falle correo, NO hagas throw
}

// --- Arranque ---
app.listen(PORT, HOST, () => {
  console.log(`[API] Ready on port ${PORT} (env: ${process.env.NODE_ENV || "dev"})`);
});


